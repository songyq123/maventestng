package com.qa.tests;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qa.base.TestBase;
import com.qa.data.Users;
import com.qa.restclient.RestClient;
import com.qa.util.FastjsonUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class order_getOrderInfoRunListTest extends TestBase {
    TestBase testBase;
    String host;
    String url;
    RestClient restClient;
    CloseableHttpResponse closeableHttpResponse;
    @BeforeClass
    public void setUp() {
        testBase = new TestBase();
        host = prop.getProperty("uHOST")+"/order/getOrderInfoRunList";
        url = host;

    }

    /**
     *  司机联盟版
     *  order/getOrderInfoRunList
     *  查询进行中订单列表
     */
    @Test(groups={"logintest"},dependsOnMethods = {"uloginManagerAppTest"})//先调用登录接口
    public void getOrderInfoRunListApiTest() throws  IOException, URISyntaxException {
        restClient = new RestClient();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到
        headermap.put("Cookie", "token="+tokenKey+";"+"sessionId="+sessionKey+";"+"product=1;platform=100;platformNo=100");
        //请求参数为null，不需要加密
        closeableHttpResponse = restClient.post1(url,null,headermap,null);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看接口请求返回的结果：" + responseString);

    }

}
