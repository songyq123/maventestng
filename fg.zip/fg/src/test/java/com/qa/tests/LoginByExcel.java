package com.qa.tests;

import com.alibaba.fastjson.JSONObject;
import com.qa.base.BaseApi;
import com.qa.common.Common;
import com.qa.data.Users;
import com.qa.restclient.RestClient;
import com.qa.util.DecryptUtil;
import com.qa.util.FastjsonUtils;
import com.qa.util.ReadExcel;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static com.qa.tests.PostApiTest.tokenKey;

public class LoginByExcel extends BaseApi{
    public static final String key="123456kcwl654321";
    RestClient restClient;
    CloseableHttpResponse closeableHttpResponse;
    public int RESPNSE_STATUS_CODE_200 = 200;
    @DataProvider(name = "post")
    public Object[][] post() throws IOException {

    //Excel表格中的sheet页来填写数字参数，第一页下标为0
    return ReadExcel.readExData(testCaseExcel,0);

    }

    @Test(dataProvider="post",dataProviderClass=LoginByExcel.class)
    public void uloginManagerAppTest1(String loginurl, String osType, String deviceId, String operatinSystem,String mobile,String password ) throws  IOException, URISyntaxException {
        //准备请求头信息
        restClient = new RestClient();
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到
        headermap.put("Cookie", Common.cookie);

        //对象转换成map键值对
        Users user = new Users(osType,deviceId,operatinSystem,mobile,password);
        Map<String, String> map= FastjsonUtils.toMap(FastjsonUtils.toJson(user));
        //map.put("platformNo","100");
        //请求参数加密成json字符串
        String encryptionData = DecryptUtil.encryptParam(map);

        String encryptionData1 = "9EFBA611D385E431FF0F50E0C7DD453B5CF9BA5CDDA36293DEBFD318D59164F67B0D7AD0DF4C05F263E514310371DBBBBC995371EC58CF716F7AD4F36C7D91AEAB77190AC01EDC40087AC9DCC2D6ACF6F990E1588DD7441E7CB8B3789894A62CE888166CD2F219FF0B6CD01DF9A36A31BF8432875CBCD9D84B8ED02C6F8CB6A9B199D9031C70BA696E05CC030AC702CAD389FC878A4748B768BB2511ABFFD9C25CE7437BB3254C6E5028B300ADD567736F17EBA564639E174C5D8B941E16298386B8293D09EF4565403B355A85F25B6CB99329AE1DC0FFDA8A889FD976A5A853237EB36B870B396E962001004EDE63DD833E3C979E35632C6929C6E267CA3FBAFA1BE0E8A1E7347A611A3FC317290B4899CEB70A88F062ACA1D5F2B9C8DC723D4854E938A98869266B882C5081E36F3DF6A29C1E73E1223A5817A7B0EA7D15A4A38B56AE481651B1670B274AC62BAF908FCD6316CCC93FED169A16D2B1BCBDB9209564E8247E38CC4390AAED136CA1C721FB8EC42C311E5ECF17EFC0C909C706642AFC8973F1DFDD83F33F66D1E4F9AE06B1722F70708741F8B7287D52F06633DCEA6334440997534B7130B5F0DE61D615B0C86226B046986C64C6B6156DA66C5A1B42ED27142EC6126EE8EEF3B30D48C8717259AED7A21B13BDD8907070E7BFBC55130A2FC6B1B4A83805B5092524EC0B869EB8584F224964C7656EB560341B932479A632B62725B79B9DFA6E6B7A9D8EE77451FB6F290AC17D558048D67D7A66A4E79690F7E846EF58FEE2822F35F32E2F9D10898DA52622CBE50ED1A06EB076B6D9A3DD8981331250179E692160873B1B01FC89B6D880C98DEDF8777DAED9EDAFA3B0A65EAD6104F6BBF53D081B7BBAF6CDE12D2B49F0B99EEF0049524F6E705088BFA71C32A987C5CCDF1B0EB1508F80A9799239972C34783257FF96C8F8A14A7274F0A0BBD8345FFB76CF78506A888695CF45D2FFED736FEC1A58CCB603DF7FCFAEFFF6344E712EBEDA0494B25F7003242410EFB77AC2EED12B9039907370E2D5387A4EB17291677FE9D9E94569BA5E287F054E2B3C47542C8D3239E70084E41ED7AE37A4B19ABC00C60B556C1B98387847F50E78FC81C0C16CFE35ED9C0F889E90AD383781ED456A2D66F50301223071F6BCD8BA691C2710868FD545BB1F371DBFED6D2F51EF6F078FAA999579FA7AC8B4EFC940AF7834E3BA8BAC69AEB8D5DDA9F06AC754A39B7CFE0F242D846233C80CD81689EE435E554C36389580EF1F29FA7D4260F1A967FE2E66C154334BD8A0DF6F3BF61E4B20943554CF223740772128BDEB9B1541544F4098EE0831138AB13EA94E262B788111A9BB8E4DEFA2BBB9E58A9A768C6B3D0A51C623BDB5E8A69E082F85A9A806CBB624C9031E7A20CE52A62826AACD1BA67066FFB7B9F42198CD03B5340723DC802BE53E9C06FDB31183BA30A8939E3C2542D50DE95799DE827B0C427DCFCB0FFC8DB43901AD8D5B7AA21049B552DB56CC6F1CB5A92780262B0FF9483B19F87B29CA34753470BDC41196E6D31B8E1657C004A01B0BB1CB27164B9632D8133A4E177E000DDBB237397FA4FEC2E3B4F663CEB8AA7C588CACC63580B6A78F301ED90E72A63DF9D3E38FE4D54C329E4E3B17C052F37BE32F94";
        //json转化为map格式的请求参数
        HashMap<String,String> encryptionDatamap = new HashMap<String,String>();
        encryptionDatamap.put("encryptionData",encryptionData);
        //解密
        try {
            String decryptedData= DecryptUtil.decryptAES(encryptionData,key);
            System.out.println(decryptedData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(encryptionData);
        //String userJsonString = JSON.toJSONString(entity);
        //System.out.println(userJsonString);
        //System.out.println(userJsonString);
        closeableHttpResponse = restClient.post1(hostManager+loginurl,null,headermap,encryptionDatamap);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容中message是不是期待结果
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看登录接口请求返回的结果：" + responseString);
        JSONObject res = FastjsonUtils.toJsonObject(responseString);
        Common.sessionKey = FastjsonUtils.toMap(res.getString("result")).get("sessionId");
        tokenKey = FastjsonUtils.toMap(res.getString("result")).get("token");
        System.out.println("message: " + res.getString("message"));
        System.out.println("sessionKey的结果: " + Common.sessionKey);
        System.out.println("tokenKey的结果: " + tokenKey);
        String message = res.getString("message");
        Assert.assertEquals(message, "登录成功","message is not 登录成功");

    }



}
