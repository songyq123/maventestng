package com.qa.tests.Order;

import com.qa.base.BaseApi;
import com.qa.restclient.RestClient;
import com.qa.util.ReadExcel;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;

public class test_order_getOrderInfoRunList extends BaseApi {

    @DataProvider(name = "order_getOrderInfoRunList")
    public Object[][] post() throws IOException {
        System.out.println("testCaseExcel: " + testCaseExcel);
        //Excel表格中的sheet页来填写数字参数，第一页下标为0
        return ReadExcel.readExData(testCaseExcel,1);

    }

    /**
     *  司机联盟版
     *  order/getOrderInfoRunList
     *  查询进行中订单列表
     */
    @Test(dataProvider="order_getOrderInfoRunList",dataProviderClass= test_order_getOrderInfoRunList.class,groups={"logintest"},dependsOnMethods = {"com.qa.tests.DriverUserController.test_driverUserController_login.test_driverUserController_login"})//先调用登录接口
    public void test_order_getOrderInfoRunList(String order_getOrderInfoRunListURL) throws  IOException, URISyntaxException {
        order_getOrderInfoRunListURL = hostManager+order_getOrderInfoRunListURL;
        restClient = new RestClient();
        //请求参数为null，不需要加密
        closeableHttpResponse = restClient.postMap(order_getOrderInfoRunListURL,null,null);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        Reporter.log("响应字符串***********："+responseString);
        System.out.println("查看接口请求返回的结果：" + responseString);

    }

}
