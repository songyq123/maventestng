package com.qa.tests;

import java.io.IOException;
import java.lang.reflect.Array;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qa.util.EntityToMap;
import com.qa.util.FastjsonUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qa.base.TestBase;
import com.qa.data.Users;
import com.qa.restclient.RestClient;
import com.qa.util.TestUtil;

public class PostApiTest extends TestBase {
    TestBase testBase;
    String host;
    String url;
    RestClient restClient;
    CloseableHttpResponse closeableHttpResponse;
    protected static String tokenKey;

    @BeforeClass
    public void setUp() {
        testBase = new TestBase();
        host = prop.getProperty("HOST")+"/driverUserController/login";
        url = host;

    }

    @Test
    public void postApiTest() throws  IOException, URISyntaxException {
        restClient = new RestClient();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到


        //对象转换成Json字符串
        Users user = new Users("0","1c7e9015","4.4.4","18096325859","1234567q");
        List<NameValuePair> param = new ArrayList<NameValuePair>();
        param.add(new BasicNameValuePair("osType",user.getOsType()));
        param.add(new BasicNameValuePair("deviceId",user.getDeviceId()));
        param.add(new BasicNameValuePair("operatinSystem",user.getOperatinSystem()));
        param.add(new BasicNameValuePair("mobile",user.getMobile()));
        param.add(new BasicNameValuePair("password",user.getPassword()));
        System.out.println(param);
        //String userJsonString = JSON.toJSONString(entity);
        //System.out.println(userJsonString);
        //System.out.println(userJsonString);
        closeableHttpResponse = restClient.post(url,headermap,param);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容是不是期待结果
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看登录接口请求返回的结果：" + responseString);
        //JSONObject res = JSON.toJsonObject(responseString);
//        JSONObject responseJson = JSON.parseObject(responseString);
//        //System.out.println(responseString);


    }

    @Test
    public void postApiTest1() throws  IOException, URISyntaxException {
        restClient = new RestClient();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到


        //对象转换成Map
        Users user = new Users("0","1c7e9015","4.4.4","18096325859","1234567q");
        Map<String, String> map= FastjsonUtils.toMap(FastjsonUtils.toJson(user));

        System.out.println(map);
        //String userJsonString = JSON.toJSONString(entity);
        //System.out.println(userJsonString);
        //System.out.println(userJsonString);
        closeableHttpResponse = restClient.post1(url,null,headermap,map);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看登录接口请求返回的结果：" + responseString);
        //JSONObject res = JSON.toJsonObject(responseString);
//        JSONObject responseJson = JSON.parseObject(responseString);
//        //System.out.println(responseString);

    }

}
