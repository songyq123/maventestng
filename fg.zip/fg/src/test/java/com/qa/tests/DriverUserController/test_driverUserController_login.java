package com.qa.tests.DriverUserController;

import com.alibaba.fastjson.JSONObject;
import com.qa.base.BaseApi;
import com.qa.common.Common;
import com.qa.data.Users;
import com.qa.restclient.RestClient;
import com.qa.util.DecryptUtil;
import com.qa.util.FastjsonUtils;
import com.qa.util.ReadExcel;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

public class test_driverUserController_login extends BaseApi{

    @DataProvider(name = "driverUserController_login")
    public Object[][] post() throws IOException {
        System.out.println("testCaseExcel: " + testCaseExcel);
        //Excel表格中的sheet页来填写数字参数，第一页下标为0
        return ReadExcel.readExData(testCaseExcel,0);

    }
    @Test(dataProvider="driverUserController_login",dataProviderClass=test_driverUserController_login.class)
    public void test_driverUserController_login(String driverUserController_loginURL, String osType, String deviceId, String operatinSystem,String mobile,String password) throws  IOException, URISyntaxException {
        driverUserController_loginURL = hostManager+driverUserController_loginURL;
        System.out.println("driverUserController_loginURL: " + driverUserController_loginURL);
        //对象转换成map键值对
        Users user = new Users(osType,deviceId,operatinSystem,mobile,password);
        Map<String, String> map= FastjsonUtils.toMap(FastjsonUtils.toJson(user));
        //请求参数加密成json字符串
        Common.encryptionData = DecryptUtil.encryptParam(map);
        //解密
        try {
            String decryptedData= DecryptUtil.decryptAES(Common.encryptionData, Common.key);
            System.out.println(decryptedData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //json转化为map格式的请求参数
        HashMap<String,String> encryptionDatamap = new HashMap<String,String>();
        encryptionDatamap.put("encryptionData",Common.encryptionData);
        restClient = new RestClient();
        closeableHttpResponse = restClient.postMap(driverUserController_loginURL,null,encryptionDatamap);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");
        //断言响应json内容中message是不是期待结果
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看登录接口请求返回的结果：" + responseString);
        Reporter.log("响应字符串***********："+responseString);
        JSONObject res = FastjsonUtils.toJsonObject(responseString);
        Common.sessionKey = FastjsonUtils.toMap(res.getString("result")).get("sessionId");
        Common.tokenKey = FastjsonUtils.toMap(res.getString("result")).get("token");
        Common.cookie = "token="+Common.tokenKey+";"+"sessionId="+Common.sessionKey+";"+"product=1;platform=100;platformNo=100";
        System.out.println("cookie: " + Common.cookie);
        String message = res.getString("message");
        Assert.assertEquals(message, "登录成功","message is not 登录成功");

    }



}
