import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FirstTest1 {

    private HttpClient httpClient = new DefaultHttpClient();
    private HttpPost httppost;
    private HttpGet httpget;
    private HttpResponse response;
    private HttpEntity entity;
    private String postResult = null;
    //post请求
    @Test
    public void loginPostTest() {

        String loginURL = "http://testshipper.bjkcwl.com/goodsOwnerrUserController/login";
        //创建一个httppost请求
        httppost = new HttpPost(loginURL);
        //创建head
        httppost.setHeader("content-type","application/x-www-form-urlencoded");
        //创建Post请求参数
        List<NameValuePair> formparams1 = new ArrayList<NameValuePair>();
        formparams1.add(new BasicNameValuePair("osType", "0"));
        formparams1.add(new BasicNameValuePair("deviceId", "1c7e9015"));
        formparams1.add(new BasicNameValuePair("operatinSystem", "4.4.4"));
        formparams1.add(new BasicNameValuePair("mobile", "18096325859"));
        formparams1.add(new BasicNameValuePair("password", "1234567q"));
        System.out.println("查看登录接口请求参数：" + formparams1);
        try {
            httppost.setEntity(new UrlEncodedFormEntity(formparams1, "UTF-8"));
            response = httpClient.execute(httppost);
            entity = response.getEntity();
            // 在这里可以用Jsoup之类的工具对返回结果进行分析，以判断创建是否成功
            postResult = EntityUtils.toString(entity, "UTF-8");

            System.out.println("查看登录接口请求返回的结果：" + postResult);
        } catch (Exception e) {
            e.printStackTrace();
        }

        httppost.releaseConnection();
    }

    //get请求
    @Test
    public void loginGetTest() throws IOException {
        String loginURL = "http://testshipper.bjkcwl.com/goodsOwnerrUserController/login?osType=0&deviceId=1c7e9015&operatinSystem=4.4.4&mobile=18096325858&password=1234567q";
        httpget = new HttpGet(loginURL);
        //创建head
        httpget.setHeader("content-type","application/x-www-form-urlencoded");
        response = httpClient.execute(httpget);
        entity = response.getEntity();
        postResult = EntityUtils.toString(entity, "UTF-8");

        System.out.println("查看登录接口请求返回的结果：" + postResult);
    }
}