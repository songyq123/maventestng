import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sun.org.apache.xpath.internal.SourceTree;
import netscape.javascript.JSObject;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class postRequestDemo {
    @Test
    public void test() throws IOException{
        //创建httpclient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();
        //创建实例对象
        String url  =  "http://testshipper.bjkcwl.com/goodsOwnerrUserController/login";
        HttpPost httpPost = new HttpPost(url);
        //设置参数
        List<NameValuePair> para = new ArrayList<>();
        para.add(new BasicNameValuePair("mobile","18900000001"));
        para.add(new BasicNameValuePair("password","1234567q"));
        para.add(new BasicNameValuePair("userType","1"));
        //list对象转成entity
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(para,"utf-8");
        httpPost.setEntity(entity);
        System.out.println(JSON.toJSONString(entity));
        httpPost.addHeader("Content-Type","application/x-www-form-urlencoded");
        //execute
        CloseableHttpResponse response = httpClient.execute(httpPost);
        //对返回值的处理
        HttpEntity responseEntity = response.getEntity();
        String responseStr = EntityUtils.toString(responseEntity);
        System.out.println(responseStr);
        //1.转换成json
        //2.转换成想要的值 result.userId
        JSONObject jsonObject = JSONObject.parseObject(responseStr);
        //获取result string
        String resultStr = jsonObject.getString("result");
        JSONObject resultObject = JSONObject.parseObject(resultStr);
        String userId = resultObject.getString("userId");
        Assert.assertEquals(userId,"216367");
        //关闭所有链接
        httpClient.close();
        response.close();
    }
}
