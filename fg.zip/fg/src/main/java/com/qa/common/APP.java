package com.qa.common;

/**
 * Created by Lihao on 2016/11/25 0025.
 */
public enum APP {
    CARRIER,//司机端
    SHIPPER,//物流端
    CRM_KC,//CRM重构-快成
    CRM_SD,//CRM重构-绥德
}
