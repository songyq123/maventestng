package com.qa.common;

import java.util.HashMap;
import java.util.Map;

public class Common {

    //访问接口路径
//测试环境
    private static String url_test_carrier_kc = "https://testcarrier.bjkcwl.com/";        //司机端-快成
    private static String url_test_carrier_sd = "https://testcarrier.sxsdkcwl.com/";      //司机端-绥德
    private static String url_test_carrier_u = "https://testucarrier.bjkcwl.com/";        //司机端-联盟
    private static String url_test_carrier_jn = "https://testucarrier.jnkcwl.com/";       //司机端-晋能
    private static String url_test_shipper_kc = "http://testshipper.bjkcwl.com/";         //物流端-快成
    private static String url_test_shipper_sd = "http://testshipper.sxsdkcwl.com/";       //物流端-绥德
    private static String url_test_shipper_u = "http://testushipper.bjkcwl.com/";         //物流端-联盟
    private static String url_test_shipper_jn = "http://testushipper.jnkcwl.com/";        //物流端-晋能
    private static String url_test_crm_kc = "http://testrecrm.bjkcwl.com/";               //CRM重构-快成
    private static String url_test_crm_sd = "http://testrecrm.sxsdkcwl.com/";             //CRM重构-绥德
    //线上环境
    private static String url_production_carrier_kc = "http://carrier.bjkcwl.com/";        //司机端-快成
    private static String url_production_carrier_sd = "http://carrier.sxsdkcwl.com/";      //司机端-绥德
    private static String url_production_carrier_u = "http://ucarrier.bjkcwl.com/";        //司机端-联盟
    private static String url_production_shipper_kc = "http://shipper.bjkcwl.com/";        //物流端-快成
    private static String url_production_shipper_sd = "http://shipper.sxsdkcwl.com/";      //物流端-绥德
    private static String url_production_shipper_u = "http://ushipper.bjkcwl.com/";        //物流端-联盟
    private static String url_production_crm_kc = "http://recrm.bjkcwl.com/";              //CRM重构-快成
    private static String url_production_crm_sd = "http://recrm.sxsdkcwl.com/";            //CRM重构-绥德

    //基本设置信息
    public static final boolean isDebug = true; //是否打印debug信息

    //当前测试平台
    public final static platform currentPlatform = platform.U;
    public  static String currentPlatformNo = "100";
    public  static String currentProduct ="1";

    //已有平台
    public enum platform {
        KC, //快成
        SD,//绥德
        U,//联盟
        JN,//晋能


    }

    public static String cookie = "product=1;platform=100;platformNo=100";//cookie
    public static String sessionKey;//登录session
    public static String tokenKey;//登录token
    public static StringBuilder requestString = new StringBuilder();//完整请求
    public static String responseString = "";//请求返回结果
    public static String encryptionData = "";//参数加密数据串
    public static Boolean currentResult = Boolean.FALSE;//当前结果
    public static final String key="123456kcwl654321";//解密key

    public static StringBuilder GenerateRequestURL(boolean isProduction, platform currentPlatform, APP app, String interfaceName) {
        StringBuilder result = new StringBuilder();

        if (!isProduction) {
            if (currentPlatform == platform.JN) {
                currentPlatformNo = "103";
                if (APP.CARRIER == app) {
                    result.append(url_test_carrier_jn);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_test_shipper_jn);
                    currentProduct = "2";
                }
            }

            if (currentPlatform == platform.KC) {
                currentPlatformNo = "101";
                if (APP.CARRIER == app) {
                    result.append(url_test_carrier_kc);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_test_shipper_kc);
                    currentProduct = "2";
                }
            }
            else if (currentPlatform == platform.SD) {
                currentPlatformNo = "102";
                if (APP.CARRIER == app) {
                    result.append(url_test_carrier_sd);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_test_shipper_sd);
                    currentProduct = "2";
                }
            }
            else if (currentPlatform == platform.U) {
                currentPlatformNo = "100";
                if (APP.CARRIER == app) {
                    result.append(url_test_carrier_u);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_test_shipper_u);
                    currentProduct = "2";
                }
            }
            else if (APP.CRM_KC == app) {
                result.append(url_test_crm_kc);
            } else if (APP.CRM_SD == app) {
                result.append(url_test_crm_sd);
            }

        } else {
            if (currentPlatform == platform.KC) {
                currentPlatformNo = "101";
                if (APP.CARRIER == app) {
                    result.append(url_production_carrier_kc);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_production_shipper_kc);
                    currentProduct = "2";
                }
            }
            else if (currentPlatform == platform.SD) {
                currentPlatformNo = "102";
                if (APP.CARRIER == app) {
                    result.append(url_production_carrier_sd);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_production_shipper_sd);
                    currentProduct = "2";
                }
            }
            else if (currentPlatform == platform.U) {
                currentPlatformNo = "100";
                if (APP.CARRIER == app) {
                    result.append(url_production_carrier_u);
                    currentProduct = "1";
                } else if (APP.SHIPPER == app) {
                    result.append(url_production_shipper_u);
                    currentProduct = "2";
                }
            }
            else if (APP.CRM_KC == app) {
                result.append(url_production_crm_kc);
            } else if (APP.CRM_SD == app) {
                result.append(url_production_crm_sd);
            }
        }

        result.append(interfaceName);

        if (isDebug) {
            Print("请求URL(不带参数)： " + result.toString());
        }

        return result;
    }

    public static void Print(String str) {
        System.out.println(str);
    }


}
