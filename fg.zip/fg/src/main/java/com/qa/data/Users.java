package com.qa.data;

public class Users {
    private String osType;
    private String deviceId;
    private String operatinSystem;
    private String mobile;
    private String password;

    public String getOsType() {
        return osType;
    }

    public void setOsType(String osType) {
        this.osType = osType;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getOperatinSystem() {
        return operatinSystem;
    }

    public void setOperatinSystem(String operatinSystem) {
        this.operatinSystem = operatinSystem;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Users() {
        super();
    }
    public Users(String osType, String deviceId, String operatinSystem, String mobile, String password) {
        this.osType = osType;
        this.deviceId = deviceId;
        this.operatinSystem = operatinSystem;
        this.mobile = mobile;
        this.password = password;
    }

    @Override
    public String toString() {
        return "Users{" +
                "osType='" + osType + '\'' +
                ", deviceId='" + deviceId + '\'' +
                ", operatinSystem='" + operatinSystem + '\'' +
                ", mobile='" + mobile + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
