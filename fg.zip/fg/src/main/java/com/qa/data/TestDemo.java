package com.qa.data;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class TestDemo {
    public static void main(String[] args) throws Exception {
        Class<Person> cls = (Class<Person>) Class.forName("com.qa.data.Person"); // 取得Class对象
        System.out.println(cls.getName()); // 反着来
        // 取得指定参数类型的构造方法
        Constructor<?> cons = cls.getConstructor(String.class, String.class);
        Method m1 = cls.getDeclaredMethod("getName");
        Method m2 = cls.getDeclaredMethod("getAge");

        Object obj = cons.newInstance("张三", "18796758475"); // 为构造方法传递参数
        System.out.println(obj); // Person [name=张三, age=20]
        Object obj1 = cls.newInstance();//里面不能使用传统的构造函数的装入newInstance("张三", 20)
        System.out.println(obj1);
        Person I = (Person)obj;
        I.say();// hi
    }


}
