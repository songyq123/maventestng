package com.qa.base;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;

import java.io.IOException;

public class JsonRequestDemo {
    @Test
    public void test() throws IOException{
        CloseableHttpClient httpClient = HttpClients.createDefault();
        String url = "http://115.28.108.130:8080/gasStation/process";
        HttpPost httpPost = new HttpPost(url);
        //设置参数
        String para = "{" +
                "\"dataSourceId\":\"bHRz\"," +
                "\"methodId\":\"00A\"," +
                "\"CardInfo\":{" +
                "\"cardNumber\":\"1234567654\","+
                "}"+
                "}";
        //list对象转成entity
        StringEntity entity = new StringEntity(para);
        System.out.println(entity);
        httpPost.setEntity(entity);
        //设置header
        httpPost.addHeader("Content-Type","application/json");
        //execute
        CloseableHttpResponse response = httpClient.execute(httpPost);
        //对返回值的处理
        HttpEntity responstEntity = response.getEntity();
        String responseStr = EntityUtils.toString(responstEntity);
        System.out.println(responseStr);
        //关闭链接
        response.close();
        httpClient.close();
    }
}
