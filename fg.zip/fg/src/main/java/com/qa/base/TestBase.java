package com.qa.base;

import com.alibaba.fastjson.JSONObject;
import com.qa.data.Users;
import com.qa.restclient.RestClient;
import com.qa.util.DecryptUtil;
import com.qa.util.FastjsonUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static com.qa.util.DecryptUtil.parseByte2HexStr;
public class TestBase {

    public Properties prop;
    public int RESPNSE_STATUS_CODE_200 = 200;
    public int RESPNSE_STATUS_CODE_201 = 201;
    public int RESPNSE_STATUS_CODE_404 = 404;
    public int RESPNSE_STATUS_CODE_500 = 500;
    RestClient restClient;
    CloseableHttpResponse closeableHttpResponse;
    protected String url;
    protected String uurl;
    protected String uuurl;
    protected static String sessionKey;
    protected static String tokenKey;
    public static final String key="123456kcwl654321";
    //写一个构造函数
    public TestBase() {

        try {
            prop = new Properties();
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+
                    "/src/main/java/com/qa/config/config.properties");
            prop.load(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @BeforeClass
    public void setUp() {

        url = prop.getProperty("HOST")+"/driverUserController/login";
        uurl = prop.getProperty("uHOST")+"/driverUserController/login";
        uuurl = prop.getProperty("uHOST")+"/order/upLoadLoadingPound";

    }

    /**
     *  司机快成版
     *  driverUserController/login
     *  登录
     */
    @Test
    public void loginManagerAppTest() throws  IOException, URISyntaxException {
        restClient = new RestClient();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到


        //对象转换成map键值对
        Users user = new Users("0","1c7e9015","4.4.4","18712358695","1234567q");
        Map<String, String> map= FastjsonUtils.toMap(FastjsonUtils.toJson(user));

        System.out.println(map);
        //String userJsonString = JSON.toJSONString(entity);
        //System.out.println(userJsonString);
        //System.out.println(userJsonString);
        closeableHttpResponse = restClient.post1(url,null,headermap,map);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容中message是不是期待结果
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看登录接口请求返回的结果：" + responseString);
        JSONObject res = FastjsonUtils.toJsonObject(responseString);
        sessionKey = FastjsonUtils.toMap(res.getString("result")).get("sessionId");
        tokenKey = FastjsonUtils.toMap(res.getString("result")).get("token");
        System.out.println("data**********: " + res.getString("message"));
        System.out.println("data**********: " + sessionKey);
        System.out.println("data**********: " + tokenKey);
        String message = res.getString("message");
        Assert.assertEquals(message, "登录成功","message is not 登录成功");

    }

    /**
     *  司机联盟版
     *  driverUserController/login
     *  登录
     */
    @Test
    public void uloginManagerAppTest() throws  IOException, URISyntaxException {
        restClient = new RestClient();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到
        headermap.put("Cookie", "token="+tokenKey+";"+"sessionId="+sessionKey+";"+"product=1;platform=100;platformNo=100");

        //对象转换成map键值对
        Users user = new Users("0","1c7e9015","4.4.4","18712358695","1234567q");
        Map<String, String> map= FastjsonUtils.toMap(FastjsonUtils.toJson(user));
        //map.put("platformNo","100");
        //请求参数加密成json字符串
        String encryptionData = DecryptUtil.encryptParam(map);

        String encryptionData1 = "e68eddad716d6a2b741481067db5ff4085e31379ded1995f76b06ec621f34378379d2d3a9d6780409685028725bdceaa15fa40fbf8a793b0755f881f9abc382533136c3e8f0c12325a58b22d0b76e286ae63a65eb6d744c261e039aeb8a002ae32d9abdfaa97fb97159a94a72621537dd290d4198ce1470395b52d490ab7d88bdb152f4383d5b027d3a6dbadb752c1e3fa81955a865c6935c77df5107ff3bd82";
        //json转化为map格式的请求参数
        HashMap<String,String> encryptionDatamap = new HashMap<String,String>();
        encryptionDatamap.put("encryptionData",encryptionData);
        //解密
        try {
            String decryptedData= DecryptUtil.decryptAES(encryptionData,key);
            System.out.println(decryptedData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(encryptionData);
        //String userJsonString = JSON.toJSONString(entity);
        //System.out.println(userJsonString);
        //System.out.println(userJsonString);
        System.out.println("loginurl: " + uurl);
        closeableHttpResponse = restClient.post1(uurl,null,headermap,encryptionDatamap);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容中message是不是期待结果
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看登录接口请求返回的结果：" + responseString);
        JSONObject res = FastjsonUtils.toJsonObject(responseString);
        sessionKey = FastjsonUtils.toMap(res.getString("result")).get("sessionId");
        tokenKey = FastjsonUtils.toMap(res.getString("result")).get("token");
        System.out.println("message: " + res.getString("message"));
        System.out.println("sessionKey的结果: " + sessionKey);
        System.out.println("tokenKey的结果: " + tokenKey);
        String message = res.getString("message");
        Assert.assertEquals(message, "登录成功","message is not 登录成功");

    }

    /**
     *  司机联盟版
     *  driverUserController/login
     *  登录
     */
    @Test
    public void uloginManagerAppTest1() throws  IOException, URISyntaxException {
        restClient = new RestClient();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        //headermap.put("Content-Type", "multipart/form-data;boundary=" ); //这个在postman中可以查询到
        headermap.put("Cookie", "token=f9d511f93b5d4f2c58973fa2913c2cdd;sessionId=372e1873f4994539a21c8019953b4639;product=1;platform=100;platformNo=100");
        //要上传的文件的路径
        String fileName1 = "c:/1.jpg";
        String postUrl  = "https://testucarrier.bjkcwl.com/order/upLoadLoadingPound";
        File fileName = new File(fileName1);
        closeableHttpResponse = restClient.postFile(postUrl,headermap,fileName);
        //验证状态码是不是200
        int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        Assert.assertEquals(statusCode, RESPNSE_STATUS_CODE_200,"status code is not 200");

        //断言响应json内容中message是不是期待结果
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity());
        System.out.println("查看上传磅单接口请求返回的结果：" + responseString);
        JSONObject res = FastjsonUtils.toJsonObject(responseString);
        String message = res.getString("message");
        Assert.assertEquals(message, "文件上传成功","message is not 文件上传成功");

    }



}
