package com.qa.base;

import com.qa.restclient.RestClient;
import com.qa.util.PropertiesUtils;
import com.qa.util.ReadExcel;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public abstract class BaseApi {
    public Properties prop;
    public static String hostManager;
    public static String testCaseExcel;
    public RestClient restClient;
    public CloseableHttpResponse closeableHttpResponse;
    public int RESPNSE_STATUS_CODE_200 = 200;

    //写一个构造函数
    public BaseApi() {

        try {
            prop = new Properties();
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+
                    "/src/main/java/com/qa/config/config.properties");
            prop.load(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    @BeforeClass
    public void setUp(){
        hostManager= prop.getProperty("uHOST");
        testCaseExcel = prop.getProperty("TESTCASEDATA");
        System.out.println("testCaseExcel: " + testCaseExcel);

    }

}
