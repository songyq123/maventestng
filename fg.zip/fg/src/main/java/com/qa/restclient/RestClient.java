package com.qa.restclient;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.qa.common.Common;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;


public class RestClient {

    //1. Get 请求方法

    public CloseableHttpResponse get(String url) throws URISyntaxException, IOException {
        //创建一个可关闭的HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();

        //创建一个HttpGet的请求对象
        HttpGet httpGet = new HttpGet(url);

        //执行请求,相当于postman上点击发送按钮，然后赋值给HttpResponse对象接收
        CloseableHttpResponse response = httpClient.execute(httpGet);

        return response;

    }

    public CloseableHttpResponse get(String url,HashMap<String,String> headermap) throws URISyntaxException, IOException {
        //创建一个可关闭的HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();

        //创建一个HttpGet的请求对象
        HttpGet httpGet = new HttpGet(url);

        //加载请求头到httpget对象
        for(Map.Entry<String, String> entry : headermap.entrySet()) {
            httpGet.addHeader(entry.getKey(), entry.getValue());
}
        //执行请求,相当于postman上点击发送按钮，然后赋值给HttpResponse对象接收
        CloseableHttpResponse response = httpClient.execute(httpGet);

        return response;

    }

    public CloseableHttpResponse post(String url, HashMap<String,String> headermap,List<NameValuePair> entity) throws URISyntaxException, IOException {
        //创建一个可关闭的HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();

        //创建一个HttpGet的请求对象
        HttpPost httpPost = new HttpPost(url);


        //设置payload
        httpPost.setEntity(new UrlEncodedFormEntity(entity, "UTF-8"));

        //加载请求头到httpget对象
        for(Map.Entry<String, String> entry : headermap.entrySet()) {
            httpPost.addHeader(entry.getKey(), entry.getValue());
        }
        //执行请求,相当于postman上点击发送按钮，然后赋值给HttpResponse对象接收
        CloseableHttpResponse response = httpClient.execute(httpPost);

        return response;

    }

    public CloseableHttpResponse post1(String url, String jsonString,HashMap<String,String> headermap,Map<String, String> param) throws URISyntaxException, IOException {
        //创建一个可关闭的HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();

        //创建一个HttpPost的请求对象
        HttpPost httpPost1 = new HttpPost(url);
        //设置payload
        // 构造请求体，创建参数队列
        if(jsonString != null && !"".equals(jsonString)) {
            httpPost1.setEntity(new StringEntity(jsonString));
        } else {
            // 构造请求体，创建参数队列
                List<NameValuePair> nvps = new ArrayList<NameValuePair>();
                if (param != null && param.size() > 0) {
                    for (Map.Entry<String, String> entry : param.entrySet()) {
                        nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                    }
            }
            httpPost1.setEntity(new UrlEncodedFormEntity(nvps));
        }

        System.out.println("请求链接"+ httpPost1.toString());

        //加载请求头到httpPost1对象
        for(Map.Entry<String, String> entry : headermap.entrySet()) {
            httpPost1.addHeader(entry.getKey(), entry.getValue());
        }
        //执行请求,相当于postman上点击发送按钮，然后赋值给HttpResponse对象接收
        CloseableHttpResponse response = httpClient.execute(httpPost1);

        return response;

    }

    public CloseableHttpResponse postMap(String url, String jsonString,Map<String, String> param) throws URISyntaxException, IOException {
        //创建一个可关闭的HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();
        //准备请求头信息
        HashMap<String,String> headermap = new HashMap<String,String>();
        headermap.put("Content-Type", "application/x-www-form-urlencoded"); //这个在postman中可以查询到
        System.out.println("cookie: " + Common.cookie);
        headermap.put("Cookie", Common.cookie);

        //创建一个HttpPost的请求对象
        HttpPost httpPost1 = new HttpPost(url);
        //设置payload
        // 构造请求体，创建参数队列
        if(jsonString != null && !"".equals(jsonString)) {
            httpPost1.setEntity(new StringEntity(jsonString));
        } else {
            // 构造请求体，创建参数队列
            List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            if (param != null && param.size() > 0) {
                for (Map.Entry<String, String> entry : param.entrySet()) {
                    nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
                }
            }
            httpPost1.setEntity(new UrlEncodedFormEntity(nvps));
        }

        System.out.println("请求链接"+ httpPost1.toString());

        //加载请求头到httpPost1对象
        for(Map.Entry<String, String> entry : headermap.entrySet()) {
            httpPost1.addHeader(entry.getKey(), entry.getValue());
        }
        //执行请求,相当于postman上点击发送按钮，然后赋值给HttpResponse对象接收
        CloseableHttpResponse response = httpClient.execute(httpPost1);

        return response;

    }

    public CloseableHttpResponse postFile(String url,HashMap<String,String> headermap,File postFile) throws URISyntaxException, IOException {
        //创建一个可关闭的HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();
        //创建一个HttpPost的请求对象
        HttpPost httpPost1 = new HttpPost(url);
        //把文件转换成流对象FileBody
        FileBody fundFileBin = new FileBody(postFile);
        //设置传输参数
        MultipartEntityBuilder multipartEntity = MultipartEntityBuilder.create();
        multipartEntity.addPart(postFile.getName(), fundFileBin);//相当于<input type="file" name="media"/>
        HttpEntity reqEntity = multipartEntity.build();
        httpPost1.setEntity(reqEntity);
        System.out.println("请求链接"+ httpPost1.toString());
        //加载请求头到httpPost1对象
        for(Map.Entry<String, String> entry : headermap.entrySet()) {
            httpPost1.addHeader(entry.getKey(), entry.getValue());
        }
        //执行请求,相当于postman上点击发送按钮，然后赋值给HttpResponse对象接收
        CloseableHttpResponse response = httpClient.execute(httpPost1);

        return response;

    }

    //传参处理，param为key=value？key=value形式，转化成list
    public void FormatProcessing(List<NameValuePair> formParms, String param) {
        String[] nameValue = param.split("&");
        for(int i=0;i<nameValue.length;i++){
            String key = nameValue[i].split("=")[0];
            String value = nameValue[i].split("=")[1];
            BasicNameValuePair basicNameValuePair = new BasicNameValuePair(key,value);
            formParms.add(basicNameValuePair);
         }

    }


}